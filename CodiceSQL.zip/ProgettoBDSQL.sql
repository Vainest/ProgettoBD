-------------------DEFINIZIONE ENTITA'--------------------------------

-----------------CREAZIONE DOMINIO 'FASCIA ORARIA'----------------
CREATE DOMAIN fascia_oraria AS integer
CHECK(
	VALUE >= 1
AND VALUE <=6
);

-------------------CREAZIONE DOMINIO 'SESSO'-------------------
CREATE DOMAIN sesso_persona AS char
CHECK(VALUE = 'M' OR VALUE = 'm' OR VALUE = 'F' OR VALUE = 'f'); 

-----------------CREAZIONE TABELLA UTENTE---------------------
CREATE TABLE Utente(
NickName VARCHAR(30) NOT NULL,
Nome VARCHAR(30) NOT NULL,
Cognome VARCHAR(30) NOT NULL,
SessoUtente sesso_persona NOT NULL, 
DataNascita DATE NOT NULL,
Nazionalita VARCHAR(30),
Password VARCHAR(20) NOT NULL,
CheckAdmin BOOLEAN DEFAULT false,

CONSTRAINT pk_Utente PRIMARY KEY(NickName),
CONSTRAINT checkData CHECK(CURRENT_DATE>DataNascita), --Controllo Data Nascita utente
CONSTRAINT checkData18 CHECK(DataNascita <= CURRENT_DATE - interval '18 year') --Controllo Età Utente >= 18 anni
);


-----------------CREAZIONE TABELLA BRANI PREFERITI------------
CREATE TABLE BraniPreferiti(
ID_BraniPreferiti SERIAL NOT NULL,
NumeroBrani INT DEFAULT 0,
TotaleMinutaggio TIME DEFAULT '00:00:00',
NickName VARCHAR(30) NOT NULL,
	
CONSTRAINT pk_BraniPreferiti PRIMARY KEY (ID_BraniPreferiti),
CONSTRAINT UnicaListaBraniP UNIQUE (NickName),
CONSTRAINT fk_Utente FOREIGN KEY (NickName) REFERENCES Utente(NickName) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE
);


-----------------CREAZIONE TABELLA ARTISTA_T------------------
CREATE TABLE Artista_T(
ID_Artista SERIAL NOT NULL,
NomeArtista VARCHAR(30) NOT NULL,
Nazionalita VARCHAR(30) NOT NULL,
SessoArtista sesso_persona NOT NULL,
DataNascita DATE NOT NULL,

CONSTRAINT pk_Artista PRIMARY KEY(ID_Artista)
);


-----------------CREAZIONE TABELLA ALBUM-----------------------
CREATE TABLE Album(
ID_Album SERIAL NOT NULL,
NomeAlbum VARCHAR(30) NOT NULL,
AnnoUscita INT NOT NULL,
N_Brani INT NOT NULL,
DurataTotale TIME NOT NULL,
ID_Artista INT NOT NULL,	
	
CONSTRAINT pk_Album PRIMARY KEY(ID_Album),
CONSTRAINT unicoAlbum UNIQUE(NomeAlbum, ID_Artista),
CONSTRAINT CheckDataAlbum CHECK(EXTRACT(YEAR from CURRENT_DATE)>=AnnoUscita), --Controllo anno uscita album sia >= dell'anno corrente
CONSTRAINT fk_Artista FOREIGN KEY (ID_Artista) REFERENCES Artista_T(ID_Artista) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE
);


-----------------CREAZIONE TABELLA TRACCIA---------------------
CREATE TABLE Traccia(
ID_Traccia SERIAL NOT NULL,
NomeTraccia VARCHAR(50) NOT NULL,
AnnoProduzione INT NOT NULL,
DurataTraccia TIME NOT NULL,
N_TotaleAscolti INT DEFAULT 0,
Genere VARCHAR(20) NOT NULL,
checkCover BOOLEAN DEFAULT false,
checkRemastering BOOLEAN DEFAULT false,
RifTracciaOriginale INT,
ID_Artista INT NOT NULL,	

CONSTRAINT pk_Traccia PRIMARY KEY(ID_Traccia),
CONSTRAINT checkDataTraccia CHECK(EXTRACT(year from CURRENT_DATE)>=AnnoProduzione), --Controllo che l'anno produzione della traccia sia >= dell'anno corrente 
CONSTRAINT fk_RifTraccia FOREIGN KEY(RifTracciaOriginale) REFERENCES Traccia (ID_Traccia) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE,
CONSTRAINT fk_ArtistaT FOREIGN KEY(ID_Artista) REFERENCES Artista_T(ID_Artista) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE,
CONSTRAINT tracciarif CHECK((checkcover = false AND checkremastering = false AND RifTracciaOriginale IS NULL) 
							OR 
						     (checkcover = true AND checkremastering = false AND RifTracciaOriginale IS NOT NULL) 
							OR
							 (checkcover = false AND checkremastering = true AND RifTracciaOriginale IS NOT NULL))
);


-----------------CREAZIONE TABELLA ASCOLTATORE--------------------
CREATE TABLE Ascoltatore(
NickName VARCHAR(20) NOT NULL,
ID_Traccia SERIAL NOT NULL,
FasciaOrariaAscolto fascia_oraria,

CONSTRAINT fk_NickName FOREIGN KEY(NickName) REFERENCES Utente(NickName) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE,
CONSTRAINT fk_Traccia FOREIGN KEY(ID_Traccia) REFERENCES Traccia(ID_Traccia) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE
);


-----------------CREAZIONE TABELLA FORMATO TRACCIA-----------------
CREATE TABLE FormatoTraccia(
ID_Album SERIAL NOT NULL,
ID_Traccia SERIAL NOT NULL,

CONSTRAINT fk_Album FOREIGN KEY(ID_Album) REFERENCES Album(ID_Album) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE,
CONSTRAINT fk_Traccia FOREIGN KEY(ID_Traccia) REFERENCES Traccia(ID_Traccia) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE
);


-----------------CREAZIONE TABELLA CONTIENETRACCE------------------
CREATE TABLE ContieneTracce(
ID_Traccia SERIAL NOT NULL,
ID_BraniPreferiti SERIAL NOT NULL,

CONSTRAINT UnicaTracciaContenuta UNIQUE(ID_Traccia, ID_BraniPreferiti),
CONSTRAINT fk_Traccia FOREIGN KEY(ID_Traccia) REFERENCES Traccia(ID_Traccia) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE,
CONSTRAINT fk_BraniPreferiti FOREIGN KEY(ID_BraniPreferiti) REFERENCES BraniPreferiti(ID_BraniPreferiti) 
	ON DELETE CASCADE 
	ON UPDATE CASCADE
);



-------------------DEFINIZIONE DELLE PROCEDURE----------------------
---------------------------------------------------------------------
--PROCEDURA 1: quando viene aggiunta una traccia bisogna aggiornare il numero di tracce e 
--			   la durata totale dell'album a cui appartiene  

CREATE FUNCTION Modifica_Colonne_Album_Inserimento() 
RETURNS TRIGGER AS $TRIGGER_Modifica_Colonne_Album_Inserimento$
BEGIN 
	UPDATE Album 
	SET N_Brani = N_Brani+1,
	    DurataTotale = (SELECT SUM(T.duratatraccia)
					   FROM FormatoTraccia as FT, Traccia AS T
					   WHERE FT.ID_Traccia = T.ID_Traccia AND NEW.ID_Album = FT.ID_Album)
	WHERE NEW.ID_Album = ID_Album;
	RETURN NULL;
END;
$TRIGGER_Modifica_Colonne_Album_Inserimento$ LANGUAGE PLPGSQL;

--TRIGGER 1: modifica il numero delle tracce e la durata totale dell'album quando viene aggiunta una traccia
CREATE OR REPLACE TRIGGER TRIGGER_Modifica_Colonne_Album_Inserimento
AFTER INSERT ON FormatoTraccia
FOR EACH ROW 
EXECUTE PROCEDURE Modifica_Colonne_Album_Inserimento(); 

---------------------------------------------------------------------
--PROCEDURA 2: Dopo l’ eliminazione di una traccia bisogna modificare il numero di tracce e
--            la durata totale dell ’ album a cui apparteneva

CREATE FUNCTION Modifica_Colonne_Album_Cancellazione()
RETURNS TRIGGER AS $TRIGGER_Modifica_Colonne_Album_Cancellazione$
BEGIN
	UPDATE Album
	SET N_Brani = N_Brani - 1,
	    DurataTotale = (SELECT SUM(T.duratatraccia)
					   FROM FormatoTraccia AS FT, Traccia AS T
					   WHERE FT.ID_Traccia = T.ID_Traccia AND OLD.ID_Album = FT.ID_Album)
	WHERE OLD.ID_Album = ID_Album;
	RETURN NULL;
END;
$TRIGGER_Modifica_Colonne_Album_Cancellazione$ LANGUAGE PLPGSQL;				   

--TRIGGER 2: modifica il numero delle tracce e il tempo dell ’ album a cui apparteneva una traccia eliminata
CREATE OR REPLACE TRIGGER TRIGGER_Modifica_Colonne_Album_Cancellazione
AFTER DELETE ON FormatoTraccia
FOR EACH ROW 
EXECUTE PROCEDURE Modifica_Colonne_Album_Cancellazione();


---------------------------------------------------------------------
--Funzione creazione branipreferiti
--PROCEDURA 3: Creazione della playlist brani preferiti quando viene aggiunto un nuovo utente

CREATE FUNCTION Creazione_BraniPreferiti()
RETURNS TRIGGER AS $TRIGGER_Creazione_BraniPreferiti$
BEGIN
	INSERT INTO BraniPreferiti(NickName)
	VALUES(NEW.Nickname);
	RETURN NULL;
END;
$TRIGGER_Creazione_BraniPreferiti$ LANGUAGE PLPGSQL;

--TRIGGER 3: creazione playlist default
CREATE OR REPLACE TRIGGER TRIGGER_Creazione_BraniPreferiti
AFTER INSERT ON Utente
FOR EACH ROW
EXECUTE PROCEDURE Creazione_BraniPreferiti();


---------------------------------------------------------------------
--PROCEDURA 4: aggiornamento del numero delle tracce e della durata di una playlist quando gli viene aggiunta una traccia

CREATE FUNCTION Modifica_Colonne_BraniPreferiti_Inserimento() 
RETURNS TRIGGER AS $TRIGGER_Modifica_Colonne_BraniPreferiti_Inserimento$
BEGIN 
	UPDATE BraniPreferiti
	SET numerobrani = numerobrani+1,
	    TotaleMinutaggio = (SELECT SUM(T.duratatraccia)
					   FROM ContieneTracce AS CT, Traccia AS T
					   WHERE CT.ID_Traccia = T.ID_Traccia AND NEW.ID_BraniPreferiti = CT.ID_BraniPreferiti)
	WHERE NEW.ID_BraniPreferiti = ID_BraniPreferiti;
	RETURN NULL;
END;
$TRIGGER_Modifica_Colonne_BraniPreferiti_Inserimento$ LANGUAGE PLPGSQL;

-- TRIGGER 4: aggiunta di una Traccia in una Playlist
CREATE OR REPLACE TRIGGER TRIGGER_Modifica_Colonne_BraniPreferiti_Inserimento
AFTER INSERT ON ContieneTracce
FOR EACH ROW 
EXECUTE PROCEDURE Modifica_Colonne_BraniPreferiti_Inserimento(); 


---------------------------------------------------------------------
--PROCEDURA 5: aggiornamento numero tracce e durata alla eliminazione di una traccia che contenuta in playlist

CREATE FUNCTION Modifica_Colonne_BraniPreferiti_Cancellazione() 
RETURNS TRIGGER AS $TRIGGER_Modifica_Colonne_BraniPreferiti_Cancellazione$
BEGIN 
	UPDATE BraniPreferiti
	SET numerobrani = numerobrani-1,
	    TotaleMinutaggio = (SELECT SUM(T.duratatraccia)
					   FROM ContieneTracce AS CT, Traccia AS T
					   WHERE CT.ID_Traccia = T.ID_Traccia AND OLD.ID_BraniPreferiti = CT.ID_BraniPreferiti)
	WHERE OLD.ID_BraniPreferiti = ID_BraniPreferiti;
	RETURN NULL;
END;
$TRIGGER_Modifica_Colonne_BraniPreferiti_Cancellazione$ LANGUAGE PLPGSQL;

-- TRIGGER 5: aggiornamento numero tracce e durata di una playlist dopo che stata eliminata una traccia che conteneva
CREATE OR REPLACE TRIGGER TRIGGER_Modifica_Colonne_BraniPreferiti_Cancellazione
AFTER DELETE ON ContieneTracce
FOR EACH ROW 
EXECUTE PROCEDURE Modifica_Colonne_BraniPreferiti_Cancellazione(); 

---------------------------------------------------------------------
--PROCEDURA 7: Controllo artista cover

CREATE OR REPLACE FUNCTION Controllo_Artista_Cover()
RETURNS TRIGGER AS $TRIGGER_Controllo_Artista_Cover$
DECLARE 

artisti Traccia.ID_artista%TYPE;
		
BEGIN
	IF(NEW.checkcover = true) THEN
		SELECT id_artista INTO artisti
		FROM Traccia
		WHERE NEW.riftracciaoriginale = id_traccia;
	IF (artisti = NEW.id_artista) THEN 
		RAISE EXCEPTION USING ERRCODE = 'ARTER';
	END IF;
	END IF;
	RETURN null;

EXCEPTION 
	WHEN SQLSTATE 'ARTER' THEN 
		RAISE NOTICE 'Nome artista cover uguale al nome dell artista della traccia originale';
		DELETE FROM Traccia
		WHERE id_traccia = NEW.id_traccia;
		RETURN NULL;
END;
$TRIGGER_Controllo_Artista_Cover$ LANGUAGE PLPGSQL;

--TRIGGER 7:
CREATE OR REPLACE TRIGGER TRIGGER_Controllo_Artista_Cover
AFTER INSERT ON Traccia
FOR EACH ROW
EXECUTE PROCEDURE Controllo_Artista_Cover();


---------------------------------------------------------------------
--PROCEDURA 8: Controllo artista remastering

CREATE OR REPLACE FUNCTION Controllo_Artista_Remastering()
RETURNS TRIGGER AS $TRIGGER_Controllo_Artista_Remastering$
DECLARE 

artisti Traccia.ID_artista%TYPE;
		
BEGIN
	IF(NEW.checkremastering = true) THEN
		SELECT id_artista INTO artisti
		FROM Traccia
		WHERE NEW.riftracciaoriginale = id_traccia;
	IF (artisti <> NEW.id_artista) THEN 
		RAISE EXCEPTION USING ERRCODE = 'ARTRE';
	END IF;
	END IF;
	RETURN null;
	
EXCEPTION 
	WHEN SQLSTATE 'ARTRE' THEN 
	RAISE NOTICE 'Nome artista remastering diverso dal nome dell artista della traccia originale';
	DELETE FROM Traccia
	WHERE id_traccia = NEW.id_traccia;
	RETURN NULL;
END;
$TRIGGER_Controllo_Artista_Remastering$ LANGUAGE PLPGSQL;

--TRIGGER 8:
CREATE OR REPLACE TRIGGER TRIGGER_Controllo_Artista_Remastering
AFTER INSERT ON Traccia
FOR EACH ROW
EXECUTE PROCEDURE Controllo_Artista_Remastering();


---------------------------------------------------------------------
--PROCEDURA 9: Controllo data Remastering

CREATE OR REPLACE FUNCTION Controllo_Data_Remastering()
RETURNS TRIGGER AS $TRIGGER_Controllo_Data_Remastering$
DECLARE 

annoprod Traccia.annoproduzione%TYPE;
		
BEGIN
	IF(NEW.checkremastering = true) THEN
		SELECT annoproduzione INTO annoprod
		FROM Traccia
		WHERE NEW.riftracciaoriginale = id_traccia;
	IF (annoprod > NEW.annoproduzione) THEN 
		RAISE EXCEPTION USING ERRCODE = 'DATRE';
	END IF;
	END IF;
	RETURN null;
	
EXCEPTION 
	WHEN SQLSTATE 'DATRE' THEN 
	RAISE NOTICE 'Anno di produzione della remastering errato, inserire anno successivo o uguale alla traccia originale';
	DELETE FROM Traccia
	WHERE id_traccia = NEW.id_traccia;
	RETURN NULL;
END;
$TRIGGER_Controllo_Data_Remastering$ LANGUAGE PLPGSQL;

--TRIGGER 9:
CREATE OR REPLACE TRIGGER TRIGGER_Controllo_Data_Remastering
AFTER INSERT ON Traccia
FOR EACH ROW
EXECUTE PROCEDURE Controllo_Data_Remastering();


---------------------------------------------------------------------
--PROCEDURA 10: Controllo data Cover

CREATE OR REPLACE FUNCTION Controllo_Data_Cover()
RETURNS TRIGGER AS $TRIGGER_Controllo_Data_Cover$
DECLARE 

annoprod Traccia.annoproduzione%TYPE;
		
BEGIN
	IF(NEW.checkcover = true) THEN
		SELECT annoproduzione INTO annoprod
		FROM Traccia
		WHERE NEW.riftracciaoriginale = id_traccia;
	IF (annoprod > NEW.annoproduzione) THEN 
		RAISE EXCEPTION USING ERRCODE = 'DATER';
	END IF;
	END IF;
	RETURN null;
EXCEPTION 
	WHEN SQLSTATE 'DATER' THEN 
	RAISE NOTICE 'Anno di produzione della cover errato, inserire anno successivo o uguale alla traccia originale';
	DELETE FROM Traccia
	WHERE id_traccia = NEW.id_traccia;
	RETURN NULL;
END;
$TRIGGER_Controllo_Data_Cover$ LANGUAGE PLPGSQL;

--TRIGGER 10:
CREATE OR REPLACE TRIGGER TRIGGER_Controllo_Data_Cover
AFTER INSERT ON Traccia
FOR EACH ROW
EXECUTE PROCEDURE Controllo_Data_Cover();


---------------------------------------------------------------------
--TRIGGER 11: Controllo cover in un album

CREATE OR REPLACE FUNCTION Controllo_Cover_Album()
RETURNS TRIGGER AS $TRIGGER_Controllo_Cover_Album$

DECLARE

checkc Traccia.checkcover%TYPE;
riforig Traccia.riftracciaoriginale%TYPE;
rifalbum formatotraccia.id_album%TYPE;

BEGIN
	SELECT T.checkcover INTO checkc
	FROM Traccia AS T
	WHERE NEW.id_traccia = T.id_traccia;

	IF(checkc = true) THEN
		SELECT T.riftracciaoriginale INTO riforig
		FROM Traccia AS T
		WHERE NEW.id_traccia = T.id_traccia;

		SELECT FT.id_album INTO rifalbum
		FROM formatotraccia AS FT
		WHERE FT.id_traccia = riforig;

	IF(NEW.id_album = rifalbum) THEN
		RAISE EXCEPTION USING ERRCODE = 'ALBER';
	END IF;
	END IF;
	RETURN null;
EXCEPTION 
	WHEN SQLSTATE 'ALBER' THEN 
	RAISE NOTICE 'La cover non può essere inserita nello stesso album di appartenenza della sua traccia originale';
	DELETE FROM formatotraccia
	WHERE id_traccia = NEW.id_traccia;
	RETURN NULL;
END;
$TRIGGER_Controllo_Cover_Album$ LANGUAGE PLPGSQL;

--TRIGGER 11:
CREATE OR REPLACE TRIGGER TRIGGER_Controllo_Cover_Album
AFTER INSERT ON formatotraccia
FOR EACH ROW
EXECUTE PROCEDURE Controllo_Cover_Album();


---------------------------------------------------------------------
--TRIGGER 12: Controllo artista in album

CREATE OR REPLACE FUNCTION Controllo_Artista_Album()
RETURNS TRIGGER AS $TRIGGER_Controllo_Artista_Album$

DECLARE

art_album album.id_artista%TYPE;
art_traccia traccia.id_artista%TYPE;

BEGIN
	SELECT A.ID_Artista INTO art_album
	FROM Album AS A
	WHERE NEW.id_Album = A.id_Album;

	SELECT T.id_artista INTO art_traccia
	FROM Traccia AS T
	WHERE NEW.id_Traccia = T.id_Traccia;


	IF (art_album <> art_traccia) THEN
		RAISE EXCEPTION USING ERRCODE = 'ARTDV';
	END IF;
	RETURN NULL;
EXCEPTION 
	WHEN SQLSTATE 'ARTDV' THEN 
	RAISE NOTICE 'L album non può contenere due artisti diversi';
	DELETE FROM formatotraccia
	WHERE id_traccia = NEW.id_traccia AND id_album = NEW.id_Album;
	RETURN NULL;
END;
$TRIGGER_Controllo_Artista_Album$ LANGUAGE PLPGSQL;

--TRIGGER 12:
CREATE OR REPLACE TRIGGER TRIGGER_Controllo_Artista_Album
AFTER INSERT ON FormatoTraccia
FOR EACH ROW
EXECUTE PROCEDURE Controllo_Artista_Album();


---------------------------------------------------------------------
---TRIGGER 13 Incremento ascolti traccia------

CREATE OR REPLACE FUNCTION Incremento_Ascolti()
RETURNS TRIGGER AS $TRIGGER_Incremento_Ascolti$
BEGIN
	UPDATE Traccia AS T
	SET n_totaleascolti = n_totaleascolti + 1
	WHERE NEW.id_traccia = T.id_traccia;
	RETURN NULL;
END;
$TRIGGER_Incremento_Ascolti$ LANGUAGE PLPGSQL;

--TRIGGER 13:
CREATE OR REPLACE TRIGGER TRIGGER_Incremento_Ascolti
AFTER INSERT ON Ascoltatore
FOR EACH ROW
EXECUTE PROCEDURE Incremento_Ascolti();


-----------------------------------------------------------------------------



-------------------------------POPOLAMENTO DEL DATABASE--------------------------------------

----------------------------------POPOLAMENTO--------------------------------------------
--POPOLAMENTO UTENTE
INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin) 
VALUES ('kale', 'Matteo', 'Monna', 'M', '2003-04-05', 'Italia', 'hdet!45', false);

INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin) 
VALUES ('Root', 'Fabrizio', 'Minino', 'M', '2002-03-04', 'Italia', 'vsaset235', false);

INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin) 
VALUES ('Bonazzoli97', 'Federico', 'Bonazzoli', 'M', '21-05-1997', 'Italia', 'ForzaSalernitana', false);

INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin)
VALUES ('Lordong', 'Lorenzo', 'D’Orio', 'M', '20-04-1999', 'Italia', 'Odino', false);

INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin) 
VALUES('PincoPallino', 'Pinco', 'Pallino', 'M', '10-10-2000', 'Francia', 'IlPallino', false);
 
INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin) 
VALUES('Ilpazzo', 'Pippo', 'Pimpante', 'M', '09-12-1980', 'Italia', '12345678',false);
 
INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin)
VALUES('Principessa78', 'Francesca', 'Marini', 'F', '24-04-1978', 'Italia', 'princess78', false);

INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin)
VALUES('amministratore1', 'Silvio', 'Barra', 'M', '24-04-1990', 'Italia', 'admin', true);

INSERT INTO utente (nickname, nome, cognome, sessoutente, datanascita, "nazionalita", password, CheckAdmin)
VALUES('amministratore2', 'Porfirio', 'Tramontana', 'M', '24-04-1990', 'Italia', 'admin', true);


-----------------------------------------------------------------------------------------
--POPOLAMENTO BRANI PREFERITI
--BRANI PREFERITI SI AUTOPOPOLA GRAZIE ALLA PROCEDURA CREATA


-----------------------------------------------------------------------------------------
--POPOLAMENTO ARTISTA
Insert INTO artista_t(id_artista, nomeartista, nazionalita, sessoartista, datanascita)
VALUES ('1', 'Geolier', 'Italiano', 'm', '2010-02-03');

INSERT INTO artista_t (id_artista, nomeartista, "nazionalita", sessoartista, datanascita) 
VALUES ('2', 'Sferaebbasta', 'Italia', 'M', '1998-01-01');

INSERT INTO artista_t (id_artista, nomeartista, "nazionalita", sessoartista, datanascita) 
VALUES ('3', 'Rocco Hunt', 'Italia', 'M', '1997-02-02');

INSERT INTO artista_t (id_artista, nomeartista, "nazionalita", sessoartista, datanascita) 
VALUES ('4', 'Shiva', 'Italia', 'M', '1999-02-02');

INSERT INTO artista_t(id_artista, nomeartista, "nazionalita", sessoartista, datanascita) 
VALUES ('5', 'Guè', 'Italia', 'M', '1995-02-02');

INSERT INTO artista_t(id_artista, nomeartista, nazionalita, sessoartista, datanascita)
VALUES('6','Marracash','italia','M','25-08-1992');
 
INSERT INTO artista_t(id_artista, nomeartista, nazionalita, sessoartista, datanascita)
VALUES('7','Guru Josh','Inghilterra','M','06-06-1964');
 
INSERT INTO artista_t(id_artista, nomeartista, nazionalita, sessoartista, datanascita)
VALUES('8','Eminem','USA','M','17-10-1972');
 
INSERT INTO artista_t(id_artista, nomeartista, nazionalita, sessoartista, datanascita)
VALUES('9','Dua Lipa','USA','F','22-08-1995');
 
INSERT INTO artista_t(id_artista, nomeartista, nazionalita, sessoartista, datanascita)
VALUES('10','Adriano Celentano','Italia','M','06-01-1938');

INSERT INTO artista_t(id_artista, nomeartista, nazionalita, sessoartista, datanascita)
VALUES('11','Davide Maresca', 'Italia', 'M', '01-01-1999');

INSERT INTO artista_t(id_artista, nomeartista, nazionalita, sessoartista, datanascita) 
VALUES('12', 'PeppeScò', 'Uzbekistan', 'M', '1999-11-04');


-------------------------------------------------------------------------------------
--POPOLAMENTO ALBUM
INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('1', '0', 'Emanuele', '2019', '00:00:00', '1');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('2', '0', 'Italiano', '2022', '00:00:00', '2');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('3', '0', 'Rivoluzione', '2010', '00:00:00', '3');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('4', '0', 'RedBarz', '2020', '00:00:00', '4');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('5', '0', 'Sinatra', '2021', '00:00:00', '5');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('6', '0', 'Noi loro gli altri', '2021', '00:00:00', '6');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('7', '0', 'Guru Josh Album', '2003', '00:00:00', '7');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('8', '0', 'Recovery', '2010', '00:00:00', '8');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('9', '0', 'Future Nostalgia', '2020', '00:00:00', '9');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('10', '0', 'La Festa', '1966', '00:00:00', '10');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('11', '0', 'Rockstar', '2018', '00:00:00', '2');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('12', '0', 'Persona', '2019', '00:00:00', '6');

INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('13', '0', 'GVESVS', '2021', '00:00:00', '5');
 
INSERT INTO album (id_album, n_brani, nomealbum, annouscita, duratatotale, id_artista) 
VALUES ('14', '0', 'La Festa (2011 REMASTERED)', '2011', '00:00:00', '10');


-------------------------------------------------------------------------------------
--POPOLAMENTO TRACCIA
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES ('1', 'Emanuele', '2021', '00:03:50', '0', 'Rap', false, false, NULL, '1');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES ('2', 'Italiano', '2021', '00:03:10', '0', 'Rap', false, false, NULL, '2');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES ('3', 'Rivoluzione', '2021', '00:02:20', '0', 'Rap', false, false, NULL, '3');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES ('4', 'Red Barz RMX', '2020', '00:03:20', '0', 'Rap', false, false, NULL, '4');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES ('5', 'Veleno', '2010', '00:03:00', '0', 'Rap', false, false, NULL, '5');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES ('6', 'LOVE', '2021', '00:03:41','0', 'Rap', false, false, NULL, '6');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES('7', 'Infinity 2008', '2008', '00:04:25', '0',  'EDM', false, false, NULL, '7');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES('8', 'Stan', '2006', '00:04:00','0', 'Rap', false, false, NULL, '8');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES('9', 'Break my heart', '2019', '00:03:51', '0', 'Pop', false, false, NULL, '9');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, rifTracciaOriginale, id_artista) 
VALUES('10', 'Il ragazzo della via', '1966', '00:04:30', '0', 'Pop', false, false, NULL, '10');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('11', 'Veleno (Remastering)', '2015', '00:03:00', '0', 'rap', false, true, '5', '5');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('12', 'Rivoluzione(Cover)', '2022', '00:02:50', '0', 'rap', true, false, '3', '11');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('13', 'Mamma mia', '2021', '00:03:00', '0', 'rap', false, false, NULL, '2');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('14', 'Chicano', '2019', '00:03:00', '0', 'Rap', false, false, NULL, '1');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('15', 'Senz E Me', '2019', '00:02:25', '0', 'Rap', false, false, NULL, '1');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('16', 'Na Catena', '2019', '00:02:45', '0', 'Rap', false, false, NULL, '1');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('17', 'Provino', '2019', '00:03:15', '0', 'Rap', false, false, NULL, '1');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('18', 'Easy', '2022', '00:03:26', '0', 'Rap', false, false, NULL, '2');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('19', 'Sola', '2022', '00:02:27', '0', 'Rap', false, false, NULL, '2');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('20', 'Popstar', '2018', '00:03:03', '0', 'Trap', false, false, NULL, '2');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('21', 'Happy Birthday', '2018', '00:02:50', '0', 'Trap', false, false, NULL, '2');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('22', 'Cupido', '2018', '00:03:31', '0', 'Trap', false, false, NULL, '2');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('23', 'Ricchi x Sempre', '2018', '00:03:43', '0', 'Trap', false, false, NULL, '2');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('24', 'Solido', '2021', '00:02:51', '0', 'Rap', false, false, NULL, '3');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('25', 'Fantastica', '2021', '00:03:07', '0', 'Rap', false, false, NULL, '3');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('26', 'L''urdemo vase', '2021', '00:03:08', '0', 'Pop', false, false, NULL, '3');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('27', 'L''urdemo vase (Rap Version)', '2021', '00:03:50', '0', 'Rap', false, true, '26', '3');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('28', 'Pensando a lei', '2020', '00:02:56', '0', 'Rap', false, false, NULL, '4');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('29', 'Niente da perdere', '2020', '00:02:46', '0', 'Rap', false, false, NULL, '4');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('30', 'Hugh Guefner', '2018', '00:01:19', '0', 'Rap', false, false, NULL, '5');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('31', 'Trap Phone', '2018', '00:03:20', '0', 'Rap', false, false, NULL, '5');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('32', 'Borsello', '2018', '00:03:22', '0', 'Rap', false, false, NULL, '5');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('33', 'Gangster Of Love', '2021', '00:02:45', '0', 'Rap', false, false, NULL, '5');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('34', 'Piango Sulla Lambo', '2021', '00:03:21', '0', 'Rap', false, false, NULL, '5');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('35', 'Blitz!', '2021', '00:03:00', '0', 'Rap', false, false, NULL, '5');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('36', 'Daytona', '2021', '00:02:42', '0', 'Rap', false, false, NULL, '5');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('37', 'Piango Sulla Lambo (EDM Remix)', '2022', '00:04:00', '0', 'EDM', false, true, '34', '5');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('38', 'Crazy Love', '2021', '00:03:21', '0', 'Rap', false, false, NULL, '6');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('39', 'Cosplayer', '2021', '00:03:41', '0', 'Rap', false, false, NULL, '6');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('40', 'Dubbi', '2021', '00:03:54', '0', 'Rap', false, false, NULL, '6');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('41', 'Noi', '2021', '00:04:32', '0', 'Rap', false, false, NULL, '6');

INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('42', 'NEON - Le Ali', '2020', '00:03:27', '0', 'Commerciale', false, false, NULL, '6');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('43', 'CRUDELIA - I nervi', '2020', '00:03:50', '0', 'Commerciale', false, false, NULL, '6');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('44', 'SUPREME - L''ego', '2020', '00:03:43', '0', 'Rap', false, false, NULL, '6');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('45', 'Love to Infinity', '2020', '00:02:48', '0', 'EDM', false, false, NULL, '7');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkremastering, checkcover, riftracciaoriginale, id_artista) 
VALUES ('46', 'Love to Infinity (CLUB MIX)', '2021', '00:03:48', '0', 'EDM', true, false, '45', '7');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('47', 'Arabian Nights', '2020', '00:03:58', '0', 'EDM', false, false, NULL, '7');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkremastering, checkcover, riftracciaoriginale, id_artista) 
VALUES ('48', 'Arabian Nights (CLUB MIX)', '2021', '00:04:00', '0', 'EDM', true, false, '47', '7');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('49', 'W.T.P.', '2010', '00:03:58', '0', 'Rap', false, false, NULL, '8');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('50', 'Not Afraid', '2010', '00:04:08', '0', 'Rap', false, false, NULL, '8');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('51', 'Levitating', '2020', '00:03:23', '0', 'Pop', false, false, NULL, '9');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('52', 'Don''t Start Now', '2020', '00:03:03', '0', 'Pop', false, false, NULL, '9');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('53', 'Sabato Triste', '1966', '00:03:22', '0', 'Pop', false, false, NULL, '10');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('54', 'Chi Ce L''ha Con Me', '1966', '00:03:18', '0', 'Pop', false, false, NULL, '10');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('55', 'Il Ragazzo Della Via Gluck - Remastered', '2011', '00:03:56', '0', 'Pop', false, true, '10', '10');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('56', 'Sabato Triste-Remastered', '2011', '00:04:01', '0', 'Pop', false, true, '53', '10');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('57', 'Chi Ce L''ha Con Me - Remastered', '2011', '00:04:00', '0', 'Pop', false, true, '54', '10');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('58', 'A Volo', '2022', '00:03:59', '0', 'Commerciale', false, false, NULL, '11');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('59', 'A Volo (Hard Remix)', '2022', '00:05:00', '0', 'EDM', false, true, '58', '11');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('60', 'The King and I', '2022', '00:03:00', '0', 'Rap', false, false, NULL, '8');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('61', 'SaraEsse', '2022', '00:04:51', '0', 'Reggeaton', false, false, NULL, '12');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('62', 'SaraEsse (Rap Version)', '2022', '00:02:59', '0', 'Rap', false, true, '61', '12');
 
INSERT INTO traccia (id_traccia, nometraccia, annoproduzione, duratatraccia, n_totaleascolti, genere, checkcover, checkremastering, riftracciaoriginale, id_artista) 
VALUES ('63', 'Stan (Cover)', '2022', '00:03:52', '0', 'Reggeaton', true, false, '8', '12');
----------------------------------------------------------------------------------
--POPOLAMENTO ASCOLTATORE
INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '1');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '2');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '3');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '4');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '5');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '6');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '7');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '8');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '9');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '10');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '1');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '5');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('kale', '10');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Root', '3');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Root', '4');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Root', '60');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Root', '22');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Root', '11');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Root', '19');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '2');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '5');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '2');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '5');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '5');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '35');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '50');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '44');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '22');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Bonazzoli97', '32');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Lordong', '1');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Lordong', '44');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Lordong', '45');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Lordong', '55');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Lordong', '22');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Lordong', '10');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Lordong', '7');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('PincoPallino', '1');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('PincoPallino', '61');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('PincoPallino', '41');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('PincoPallino', '50');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Ilpazzo', '1');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Ilpazzo', '51');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Ilpazzo', '31');

INSERT INTO Ascoltatore(NickName, ID_Traccia)
VALUES ('Principessa78', '1');


-----------------------------------------------------------------------------
--POPOLAMENTO FORMATO TRACCIA
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('1','1');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('2','2');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('2','13');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('3','3');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('4','4');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('5','5');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('6','6');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('7','7');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('8','8');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('9','9');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('10','10');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('1','14');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('1','15');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('1','16');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('1','17');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('2','18');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('2','19');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('11','20');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('11','21');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('11','22');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('11','23');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('3','24');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('3','25');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('3','26');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('3','27');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('4','28');
	
INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('4','29');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('5','30');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('5','31');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('5','32');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('13','33');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('13','34');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('13','35');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('13','36');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('13','37');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('6','38');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('6','39');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('6','40');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('6','41');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('12','42');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('12','43');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('12','44');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('7','45');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('7','46');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('7','47');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('7','48');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('8','49');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('8','50');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('9','51');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('9','52');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('10','53');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('10','54');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('14','55');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('14','56');

INSERT INTO FormatoTraccia(ID_Album, ID_Traccia)
VALUES('14','57');

-------------------------------------------------------------------------------
--POPOLAMENTO CONTIENETRACCIA

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('1', '1');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('2', '1');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('3', '1');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('4', '1');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('51', '1');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('31', '1');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('39', '1');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('1', '2');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('3', '2');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('1', '3');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('2', '3');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('4', '3');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('24', '3');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('17', '3');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('1', '4');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('10', '5');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('5', '5');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('6', '5');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('3', '6');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('9', '6');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('7', '7');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('9', '7');

INSERT INtO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('10', '7');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('2', '7');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('1', '8');

INSERT INTO ContieneTracce(ID_Traccia, ID_BraniPreferiti)
VALUES ('10', '8');


--------------------------------------------------------------------------------

---------------------------PERMESSI UTENTI E AMMINISTRATORE----------------------

CREATE USER UtenteBase PASSWORD '12345';
GRANT SELECT on Utente to UtenteBase ;
GRANT SELECT on Traccia to UtenteBase ;
GRANT SELECT on Album to UtenteBase ;
GRANT SELECT on Artista_t to UtenteBase ; 
GRANT INSERT on Ascoltatore to UtenteBase ;
GRANT SELECT on BraniPreferiti to UtenteBase ; 
GRANT SELECT on ContieneTracce to UtenteBase ;
GRANT SELECT on FormatoTraccia to UtenteBase ;
GRANT INSERT on ContieneTracce to UtenteBase ;
GRANT UPDATE on ContieneTracce to UtenteBase ;
GRANT DELETE on ContieneTracce to UtenteBase ;


 
 CREATE USER UtenteAdmin PASSWORD 'admin';
 GRANT ALL on BraniPreferiti to UtenteAdmin ;
 GRANT ALL on Ascoltatore to UtenteAdmin ;
 GRANT ALL on Utente to UtenteAdmin ;
 GRANT ALL on Traccia to UtenteAdmin ;
 GRANT ALL on Album to UtenteAdmin ;
 GRANT ALL on Artista_t to UtenteAdmin ;
 GRANT ALL on ContieneTracce to UtenteAdmin ;
 GRANT ALL on FormatoTraccia to UtenteAdmin ;
 
 
 
















